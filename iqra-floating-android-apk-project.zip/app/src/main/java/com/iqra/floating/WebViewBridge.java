package com.iqra.floating;

import android.app.Activity;
import android.content.Intent;
import android.speech.tts.TextToSpeech;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import java.util.Locale;

public class WebViewBridge {
    private final Activity activity;
    private final String initialText;
    private final boolean isFloating;
    private TextToSpeech tts;
    private boolean ttsReady = false;

    public WebViewBridge(Activity activity, String initialText, boolean isFloating) {
        this.activity = activity;
        this.initialText = initialText != null ? initialText : "";
        this.isFloating = isFloating;
        this.tts = new TextToSpeech(activity.getApplicationContext(), status -> {
            if (status == TextToSpeech.SUCCESS) {
                int res = tts.setLanguage(new Locale("ar"));
                ttsReady = (res != TextToSpeech.LANG_MISSING_DATA && res != TextToSpeech.LANG_NOT_SUPPORTED);
            }
        });
    }

    @JavascriptInterface
    public String getInitialText() {
        return initialText;
    }

    @JavascriptInterface
    public boolean isFloatingWindow() {
        return isFloating;
    }

    @JavascriptInterface
    public void closeFloatingWindow() {
        activity.runOnUiThread(activity::finish);
    }

    @JavascriptInterface
    public void speakAndroidTts(String text, float rate) {
        if (tts != null && ttsReady) {
            tts.setSpeechRate(rate > 0 ? rate : 1.0f);
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "iqra_utt");
        }
    }

    @JavascriptInterface
    public void stopAndroidTts() {
        if (tts != null) {
            tts.stop();
        }
    }

    public void shutdown() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
    }
}
